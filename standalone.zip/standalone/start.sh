#!/bin/bash
export AZURE_OPENAI_API_KEY=83388c6e2b2646589803eb361f000c45
export AZURE_OPENAI_ENDPOINT=https://codeeditor.openai.azure.com
export AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o
export AZURE_OPENAI_API_VERSION=2024-05-01-preview
node server.js
