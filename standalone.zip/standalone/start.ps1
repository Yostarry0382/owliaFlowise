# OwliaFabrica Standalone Startup Script (PowerShell)

# Load environment variables from .env.local
$envFile = Join-Path $PSScriptRoot ".env.local"
if (Test-Path $envFile) {
    Get-Content $envFile | ForEach-Object {
        if ($_ -match "^\s*([^#][^=]+)=(.*)$") {
            $name = $matches[1].Trim()
            $value = $matches[2].Trim()
            [System.Environment]::SetEnvironmentVariable($name, $value, "Process")
            Write-Host "Set: $name"
        }
    }
} else {
    Write-Host "Warning: .env.local not found at $envFile"
}

Write-Host ""
Write-Host "=== OwliaFabrica Standalone ==="
Write-Host "Azure OpenAI Endpoint: $env:AZURE_OPENAI_ENDPOINT"
Write-Host "Deployment: $env:AZURE_OPENAI_DEPLOYMENT_NAME"
Write-Host ""

# Start the server
node server.js
