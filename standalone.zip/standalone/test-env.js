const fs = require('fs');
const path = require('path');

const envPath = path.join(__dirname, '.env.local');
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, 'utf-8');
  envContent.split('\n').forEach(line => {
    const trimmed = line.trim();
    if (trimmed && !trimmed.startsWith('#')) {
      const [key, ...valueParts] = trimmed.split('=');
      const value = valueParts.join('=');
      if (key && value !== undefined) {
        process.env[key.trim()] = value.trim();
      }
    }
  });
}

console.log('=== Environment Variables Test ===');
console.log('AZURE_OPENAI_API_KEY:', process.env.AZURE_OPENAI_API_KEY ? 'SET (' + process.env.AZURE_OPENAI_API_KEY.substring(0, 10) + '...)' : 'NOT SET');
console.log('AZURE_OPENAI_ENDPOINT:', process.env.AZURE_OPENAI_ENDPOINT || 'NOT SET');
console.log('AZURE_OPENAI_DEPLOYMENT_NAME:', process.env.AZURE_OPENAI_DEPLOYMENT_NAME || 'NOT SET');
console.log('AZURE_OPENAI_API_VERSION:', process.env.AZURE_OPENAI_API_VERSION || 'NOT SET');

// Test Azure OpenAI connection
async function testAzureOpenAI() {
  const apiKey = process.env.AZURE_OPENAI_API_KEY;
  const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
  const deployment = process.env.AZURE_OPENAI_DEPLOYMENT_NAME;
  const apiVersion = process.env.AZURE_OPENAI_API_VERSION || '2024-02-15-preview';

  if (!apiKey || !endpoint || !deployment) {
    console.log('\n❌ Missing Azure OpenAI configuration');
    return;
  }

  // Ensure endpoint ends with /
  const normalizedEndpoint = endpoint.endsWith('/') ? endpoint : endpoint + '/';
  const url = `${normalizedEndpoint}openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`;
  console.log('\n=== Testing Azure OpenAI ===');
  console.log('URL:', url);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'api-key': apiKey,
      },
      body: JSON.stringify({
        messages: [{ role: 'user', content: 'Hello' }],
        max_tokens: 10,
      }),
    });

    console.log('Status:', response.status);
    const data = await response.text();
    console.log('Response:', data.substring(0, 500));
  } catch (error) {
    console.log('Error:', error.message);
  }
}

testAzureOpenAI();
