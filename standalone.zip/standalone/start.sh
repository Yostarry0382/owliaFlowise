#!/bin/bash
cd "$(dirname "$0")"
node server.js
